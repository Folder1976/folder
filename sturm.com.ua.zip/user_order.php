<?php
include 'init.lib.php';
//session_start();
connect_to_mysql();
require("JsHttpRequest.php");
$JsHttpRequest=new JsHttpRequest("utf8");//"windows-1251");


if(!isset($_SESSION[BASE.'userid'])){
 
    echo "nouser";
}else{

//==================================SETUP=MENU==========================================
$setup = mysql_query("SET NAMES utf8");
$tQuery = "SELECT 
	  `setup_menu_name`, 
	  `setup_menu_".$_SESSION[BASE.'lang']."`
	  FROM `tbl_setup_menu`
	  WHERE
	  `setup_menu_name` like '%menu%'";

$setup = mysql_query($tQuery);
$m_setup = array();
$count=0;
while ($count<mysql_num_rows($setup)){
 $m_setup[mysql_result($setup,$count,0)]=mysql_result($setup,$count,1);
 $count++;
}


//echo "hhhhhh";
if($_REQUEST['order']=="send"){

//header ('Refresh: 0; url=' . '/admin/set_status.php?stat=15&nakl=2382');


//echo  $_REQUEST['value'], " ", $_REQUEST['id'];
}
//=================================================================
if($_REQUEST['order']=="del"){
  if($_SESSION[BASE.'userorder']){
      $tQuery = "DELETE FROM `tbl_operation_detail` WHERE 
			    `operation_detail_tovar`='".(int)mysql_real_escape_string($_REQUEST['id'])."' and
			    `operation_detail_operation`='".$_SESSION[BASE.'userorder']."'";
  //echo $tQuery;
      $ver = mysql_query($tQuery);
      set_operation_summ();
  }
echo $m_setup['menu unit dell'];
}
//echo "value:",$_REQUEST['value']," - id",$_REQUEST['id'], " - order:",$_REQUEST['order'];
if($_REQUEST['order']=="opa"){
	$tQuery = "SELECT `opa_id` FROM `tbl_opa` WHERE
			    `opa_klient`='".$_SESSION[BASE.'userid']."' and
			    `opa_tovar`='".(int)mysql_real_escape_string($_REQUEST['id'])."'
			    ";
	$ver = mysql_query($tQuery);
	  if(mysql_num_rows($ver)>0){
	      echo $m_setup['menu opa present'];
	  }else{

	      $tQuery = "INSERT INTO `tbl_opa` SET 
			    `opa_klient`='".$_SESSION[BASE.'userid']."',
			    `opa_tovar`='".(int)mysql_real_escape_string($_REQUEST['id'])."',
			    `opa_item`='".(int)mysql_real_escape_string($_REQUEST['value'])."'
			    ";
	      $ver = mysql_query($tQuery);
	      echo $m_setup['menu opa add'];
	  }
}
//=====================================================
if($_REQUEST['order']=="add"){
//echo $_SESSION[BASE.'userorder'];
    if($_SESSION[BASE.'userorder']==-1){
	add_new_order();
    }
    if(!isset($_SESSION[BASE.'userorder'])){
	add_new_order();
    }

    add_new_item((int)mysql_real_escape_string($_REQUEST['value']),(int)mysql_real_escape_string($_REQUEST['id']));
     echo $m_setup['menu order add'];

}
}
function get_zakup($id){
$setup = mysql_query("SET NAMES utf8");
$tQuery = "SELECT  (`currency_ex`*`price_tovar_1`)
	    FROM `tbl_currency`,`tbl_price_tovar`
	    WHERE `price_tovar_id`='$id' and `price_tovar_curr_1`=`currency_id`
	  ";
$setup = mysql_query($tQuery);

}
function add_new_item($value,$id) {
   $ver = mysql_query("SET NAMES utf8");
  $tQuery = "INSERT INTO `tbl_operation_detail` SET 
			    `operation_detail_operation`='".$_SESSION[BASE.'userorder']."',
			    `operation_detail_tovar`='".$id."',
			    `operation_detail_item`='".$value."',
			    `operation_detail_zakup`= (SELECT  (`currency_ex`*`price_tovar_1`)
							FROM `tbl_currency`,`tbl_price_tovar`
							WHERE 
							  `price_tovar_id`='$id' and 
							  `price_tovar_curr_1`=`currency_id`),
			    `operation_detail_price`= 
						(SELECT 
						  (`price_tovar_".$_SESSION[BASE.'userprice']."`*
						      (SELECT `currency_ex` 
							FROM 
							  `tbl_currency`,
							  `tbl_price_tovar`
							WHERE 
							  `price_tovar_curr_".$_SESSION[BASE.'userprice']."`=`currency_id` and
							  `price_tovar_id`='$id'
						      )
						  ) as price 
						FROM `tbl_price_tovar` 
						WHERE `price_tovar_id`='".$id."'),
			    `operation_detail_discount`='".$_SESSION[BASE.'userdiscount']."',
			    `operation_detail_summ`=(".$value." * (SELECT 
						      (`price_tovar_".$_SESSION[BASE.'userprice']."`*
							(SELECT `currency_ex` 
							  FROM 
							    `tbl_currency`,
							    `tbl_price_tovar`
							  WHERE 
							    `price_tovar_curr_".$_SESSION[BASE.'userprice']."`=`currency_id` and
							    `price_tovar_id`='$id'
							)
						      ) as summ FROM `tbl_price_tovar` WHERE `price_tovar_id`='".$id."'))/100*(100-".$_SESSION[BASE.'userdiscount']."),
			    `operation_detail_memo`='',
			    `operation_detail_from`='0',
			    `operation_detail_to`='0',
			    `operation_detail_dell`='0'
			    ";
  $ver = mysql_query($tQuery);
    if (!$ver){
      echo "Query error",$tQuery;
      exit();
    }
set_operation_summ();
//echo $tQuery;
}


function set_operation_summ(){
  $sum = mysql_query("SET NAMES utf8");
  $tQuery = "SELECT SUM(`operation_detail_summ`) AS sum FROM `tbl_operation_detail` 
	    WHERE `operation_detail_operation`='".$_SESSION[BASE.'userorder']."' and
	    `operation_detail_dell`='0'";
  $sum = mysql_query($tQuery);
 //echo $tQuery;
   $sumup = mysql_query("SET NAMES utf8");
  $tQuery = "UPDATE `tbl_operation` SET `operation_summ`='".number_format(mysql_result($sum,0,0),2,".","")."'
	    WHERE `operation_id`='".$_SESSION[BASE.'userorder']."' and
	    `operation_dell`='0'";
    $sumup = mysql_query($tQuery);

 $_SESSION[BASE.'userordersumm'] = number_format(mysql_result($sum,0,0),2,".","");
}

function add_new_order() {
$date = date("Y-m-d G:i:s");

  $ver = mysql_query("SET NAMES utf8");
  $tQuery = "INSERT INTO `tbl_operation` SET ";
  $tQuery .= "`operation_data`='".$date."',";
  $tQuery .= "`operation_klient`='".$_SESSION[BASE.'userid']."',";
  $tQuery .= "`operation_prodavec`='1',";
  $tQuery .= "`operation_sotrudnik`='-1',";
  $tQuery .= "`operation_data_edit`='".$date."',";
  $tQuery .= "`operation_status`='16',";
  $tQuery .= "`operation_summ`='0',";
  $tQuery .= "`operation_memo`='-',";
  $tQuery .= "`operation_inet_id`='0',";
  $tQuery .= "`operation_dell`='0'";
  $ver = mysql_query($tQuery);
    if (!$ver){
      echo "Query error";
      exit();
    }
 $_SESSION[BASE.'userorder'] = mysql_insert_id();    
 $_SESSION[BASE.'userordersumm'] = 0;    
 
}



?>
