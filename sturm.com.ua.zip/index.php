<?php
//ini_set("memory_limit", "128000000"); 
//echo "fff";
include 'init.lib.php';
include 'init.lib.user.php';
include 'init.lib.user.tovar.php';
//set_base_define();
//echo phpinfo();
connect_to_mysql();
//session_start();
if(!isset($_SESSION[BASE.'chat'])){
  $_SESSION[BASE.'chat'] = "small";
}

if(strpos(mb_strtoupper($_SERVER['REQUEST_URI']),"SELECT")>0) exit();
if(strpos(mb_strtoupper($_SERVER['REQUEST_URI']),"+UNION")>0) exit();
if(strpos(mb_strtoupper($_SERVER['REQUEST_URI']),"+ALL")>0) exit();
//if(strpos($_SERVER['REQUEST_URI'],"%")>0) exit();



echo "
<!DOCTYPE html>
<html>
<head>
<title>sturm.com.ua</title>    
<link rel=\"shortcut icon\" href=\"resources/favicon.png\" type=\"image/png\">
<meta http-equiv=\"Content-Type\" content=\"text/html;charset=utf-8\">
	<link rel=\"stylesheet\" type=\"text/css\" media=\"all\" href=\"styles.css\">
	<link rel=\"stylesheet\" medis=\"screen\" type=\"text/css\" href=\"sturm.css\">
	<script type=\"text/javascript\" src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js\"></script>
        <script language=\"javascript\" src=\"admin/JsHttpRequest.js\"></script>
    
";



if(verify_black_list($_SERVER['REMOTE_ADDR']))
{
  echo "Your IP - ",$_SERVER['REMOTE_ADDR']," blocked!";
  exit();
}
save_log($_SERVER['REMOTE_ADDR'],$_SERVER["PHP_SELF"]."?".$_SERVER['QUERY_STRING']);

//$menu_information = "";
$temp_header = "admin/template/main.html";
$tmp_header = file_get_contents($temp_header);  
$user_level=10;
//if(!isset($_SESSION[BASE.'userlevel']))$_SESSION[BASE.'userlevel']=1;
if(!isset($_SESSION[BASE.'username']))$_SESSION[BASE.'username']=null; 
if(!isset($_SESSION[BASE.'usersetup']))$_SESSION[BASE.'usersetup']=null; 
if(!isset($_SESSION[BASE.'userlevel']))$_SESSION[BASE.'userlevel']=$user_level; 
if(!isset($_SESSION[BASE.'userdiscount']))$_SESSION[BASE.'userdiscount']=0; 
if(!isset($_SESSION[BASE.'usergroup_setup']))$_SESSION[BASE.'usergroup_setup']=null; 


$key = "";
if(isset($_REQUEST['key'])) $key=(string)$_REQUEST['key'];
if($key=="exit"){
$_SESSION[BASE.'login']=null;
$_SESSION[BASE.'userid']=null;
$_SESSION[BASE.'username']=null;
$_SESSION[BASE.'usersetup']=null;
$_SESSION[BASE.'pass']=null;
$_SESSION[BASE.'userorder']=null;
$_SESSION[BASE.'userordersumm']=null;
$_SESSION[BASE.'userlevel']=$user_level;
$_SESSION[BASE.'userprice']=null;
$_SESSION[BASE.'userdiscount']=null;
$_SESSION[BASE.'usergroup_setup']=null;
}

  if(!isset($_SESSION[BASE.'lang']))$_SESSION[BASE.'lang']=1;
  
  if (isset($_REQUEST['lang'])){
    $_SESSION[BASE.'lang'] = (int)mysql_real_escape_string($_REQUEST['lang']);
    $_SESSION[BASE.'user menu']=null;
	if ($_SESSION[BASE.'lang'] <1){
	      $_SESSION[BASE.'lang']=1;
	}
	if ($_SESSION[BASE.'lang'] >3){
	      $_SESSION[BASE.'lang']=1;
	}
  }
   
//==================================SETUP=MENU==========================================
$setup = mysql_query("SET NAMES utf8");
$tQuery = "SELECT 
	  `setup_menu_name`, 
	  `setup_menu_".$_SESSION[BASE.'lang']."`
	  FROM `tbl_setup_menu`";
	  //WHERE	  `setup_menu_name` like '%menu%'";

$setup = mysql_query($tQuery);
$k_setup = array();
$m_setup = array();
$count=0;
while ($count<mysql_num_rows($setup)){
 $m_setup[mysql_result($setup,$count,0)]=mysql_result($setup,$count,1);
 $k_setup[mysql_result($setup,$count,0)]=mysql_result($setup,$count,1);
 $count++;
}

$setup = mysql_query("SET NAMES utf8");
$tQuery = "SELECT *
	  FROM `tbl_setup`
	  ";

$setup = mysql_query($tQuery);

$count=0;
while ($count<mysql_num_rows($setup)){
 $k_setup[mysql_result($setup,$count,0)]=mysql_result($setup,$count,1);
 $m_setup[mysql_result($setup,$count,0)]=mysql_result($setup,$count,1);
 $count++;
 
}

if(!isset($m_setup['web default price'])){
$m_setup['web default price'] = $k_setup['web default price'];
}
//=================================================================  
if(isset($_REQUEST['comment_txt'])){
  $comment_txt = (string)mysql_real_escape_string($_REQUEST['comment_txt']);
  $dell = array("<",
		">",
		"img",
		"src",
		"script",
		"php",
		"\"",
		"'",
		"href"
		);
  $comment_txt = str_replace($dell,"*",$comment_txt);
  
  $tmp = mysql_query("SET NAMES utf8");
  $tmp = mysql_query("SELECT `comments_klient` FROM `tbl_comments` WHERE `comments_memo`='".$comment_txt."' and `comments_tovar`='".mysql_real_escape_string($_REQUEST['tovar'])."'");
 
  if(mysql_num_rows($tmp)==0){
      $tmp = mysql_query("SET NAMES utf8");
      $tmp = mysql_query("INSERT INTO `tbl_comments` 
		      (`comments_tovar`,`comments_klient`,`comments_memo`)
		      VALUES
		      ('".(int)mysql_real_escape_string($_REQUEST['tovar'])."',
			'".$_SESSION[BASE.'userid']."',
			'".$comment_txt."')
		      ");
  }
}
//==================================================================
//echo $_REQUEST["login"],$_REQUEST["pass"],$_REQUEST["logining"]=='1',"<br>";

if(isset($_REQUEST["pass"]) and !-empty($_REQUEST["login"]) and $_REQUEST["logining"]=='1'){
$ver = mysql_query("SET NAMES utf8");
$sqlStr = "SELECT 
		    `klienti_name_1`,
		    `klienti_id`,
		    `klienti_setup`,
		    `klienti_email`,
		    `klienti_discount`,
		    `klienti_inet_id`,
		    `klienti_price`,
		    `klienti_group_setup`
		    FROM `tbl_klienti`,`tbl_klienti_group` 
		    WHERE upper(`klienti_email`)='".mb_strtoupper(addslashes(mysql_real_escape_string($_REQUEST["login"])),'UTF-8')."' 
		    and `klienti_pass`='".md5((string)mysql_real_escape_string($_REQUEST["pass"]))."'
		    and `klienti_group`=`klienti_group_id`
		    ";
$ver = mysql_query($sqlStr);
//echo $sqlStr;
//exit();
//upper(`tovar_artkl`) LIKE '%".mb_strtoupper(addslashes($searchq),'UTF-8')."%'
if (!$ver)
{

//echo "1 User not found or login+pass not corect!";
if(strpos($_REQUEST['web'],"key=exit")) $web = "/index.php?user=new";
if(!isset($_SESSION[BASE.'userid'])) $web = "/index.php?user=new";
header ('Refresh: 0; url='.$web);
}
$curr = mysql_query("SET NAMES utf8");
$curr = mysql_query("SELECT 
		    `currency_name_shot` FROM `tbl_currency` 
		    WHERE `currency_id`='1'");
		    
if(mysql_num_rows($ver)==0){
//echo "<b> User not found or login+pass not corect!</b>";
$web = $_REQUEST['web'];
if(strpos($_REQUEST['web'],"key=exit")) $web = "/index.php";
if(!isset($_SESSION[BASE.'userid'])) $web = "/index.php?user=new";
header ('Refresh: 0; url='.$web);
}else{
    if(empty($_SESSION[BASE.'userorder'])){
	$oper = mysql_query("SET NAMES utf8");
	$oper = mysql_query("SELECT 
		    `operation_id`,
		    `operation_summ`
		    FROM `tbl_operation` 
		    WHERE `operation_klient`='".mysql_result($ver,0,"klienti_id")."' 
		    and `operation_status`='16'
		    and `operation_dell`='0'");
	if(mysql_num_rows($oper)>0){
	      $_SESSION[BASE.'userorder']=mysql_result($oper,0,"operation_id");
	      $_SESSION[BASE.'userordersumm']=mysql_result($oper,0,"operation_summ");
	}else{
	      $_SESSION[BASE.'userorder']=null;
	      $_SESSION[BASE.'userordersumm']=null;
	}
    }
   
$_SESSION[BASE.'login']=mysql_result($ver,0,"klienti_email");
$_SESSION[BASE.'userlevel']=mysql_result($ver,0,"klienti_inet_id");
$_SESSION[BASE.'username']=mysql_result($ver,0,"klienti_name_1");
$_SESSION[BASE.'userid']=mysql_result($ver,0,"klienti_id");
$_SESSION[BASE.'usersetup']=mysql_result($ver,0,"klienti_setup");
$_SESSION[BASE.'userdiscount']=mysql_result($ver,0,"klienti_discount");
$_SESSION[BASE.'userprice']=mysql_result($ver,0,"klienti_price");
$_SESSION[BASE.'usercurr']=mysql_result($curr,0,0);
$_SESSION[BASE.'usergroup_setup']=mysql_result($ver,0,"klienti_group_setup");

$sSQL = "UPDATE `tbl_klienti` SET `klienti_ip`='".$_SERVER['REMOTE_ADDR']."' WHERE `klienti_id`='".$_SESSION[BASE.'userid']."'";
$ver = mysql_query($sSQL);
}
$web = mysql_real_escape_string($_REQUEST['web']);
if(strpos($_REQUEST['web'],"key=exit")) $web = "/index.php";
if(!isset($_SESSION[BASE.'userid'])) $web = "/index.php?user=new";
header ('Refresh: 0; url='.$web);
}
//==================================================================

if (!isset($_SESSION[BASE.'userprice'])){
  $_SESSION[BASE.'userprice'] = $k_setup['web default price'];
}


header ('Content-Type: text/html; charset=utf-8');

echo "
	    	<!-- Google Analytics -->
<script type=\"text/javascript\">
var _gaq = _gaq || [];
_gaq.push([\"_setAccount\", \"UA-25572985-1\"]);
_gaq.push([\"_addOrganic\", \"blogs.yandex.ru\", \"text\"]);
_gaq.push([\"_addOrganic\", \"go.mail.ru\", \"q\"]);
_gaq.push([\"_addOrganic\", \"gogo.ru\", \"q\"]);
_gaq.push([\"_addOrganic\", \"nova.rambler.ru\", \"query\"]);
_gaq.push([\"_addOrganic\", \"rambler.ru\", \"words\"]);
_gaq.push([\"_addOrganic\", \"nigma.ru\", \"s\"]);
_gaq.push([\"_addOrganic\", \"search.qip.ru\", \"query\"]);
_gaq.push([\"_addOrganic\", \"webalta.ru\", \"q\"]);
_gaq.push([\"_addOrganic\", \"aport.ru\", \"r\"]);
_gaq.push([\"_addOrganic\", \"liveinternet.ru\", \"ask\"]);
_gaq.push([\"_addOrganic\", \"gde.ru\", \"keywords\"]);
_gaq.push([\"_addOrganic\", \"quintura.ru\", \"request\"]);
_gaq.push([\"_addOrganic\", \"poisk.ru\", \"text\"]);
_gaq.push([\"_addOrganic\", \"km.ru\", \"sq\"]);
_gaq.push([\"_addOrganic\", \"bigmir.net\", \"q\"]); 
_gaq.push([\"_addOrganic\", \"akavita.by\", \"z\"]);
_gaq.push([\"_addOrganic\", \"tut.by\", \"query\"]);
_gaq.push([\"_addOrganic\", \"all.by\", \"query\"]); 
_gaq.push([\"_addOrganic\", \"i.ua\", \"q\"]);
_gaq.push([\"_addOrganic\", \"meta.ua\", \"q\"]);
_gaq.push([\"_addOrganic\", \"online.ua\", \"q\"]);
_gaq.push([\"_addOrganic\", \"a.ua\", \"s\"]);
_gaq.push([\"_addOrganic\", \"ukr.net\", \"search_query\"]);
_gaq.push([\"_addOrganic\", \"search.com.ua\", \"q\"]);
_gaq.push([\"_addOrganic\", \"search.ua\", \"query\"]); 
_gaq.push([\"_addOrganic\", \"search.babylon.com\", \"q\"]);
_gaq.push([\"_addOrganic\", \"icq.com\", \"q\"]);
_gaq.push([\"_addOrganic\", \"search.winamp.com\", \"q\"]); 
_gaq.push([\"_trackPageview\"]);
(function() {
	var ga = document.createElement(\"script\");
	ga.type = \"text/javascript\";
	ga.async = true;
	ga.src = (\"https:\" == document.location.protocol ? \"https://ssl\" : \"http://www\") + \".google-analytics.com/ga.js\";
	var s = document.getElementsByTagName(\"script\")[0]; s.parentNode.insertBefore(ga, s);
})();
</script>
<!-- /Google Analytics -->
      <script type=\"text/javascript\">
  
	  var _gaq = _gaq || [];
	  _gaq.push(['_setAccount', 'UA-21375481-1']);
	  _gaq.push(['_trackPageview']);

	  (function() {
		var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
		ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
		var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
	})();
      </script>
      
      <script>
      function clear_field(){
	 // alert('gg');
	  document.getElementById('comment_txt').value='';
      }
      function hidde_elem(){
	if(getObj('city').value == '' || getObj('city').value == '",$m_setup['menu find-str'],"')
	  getObj('info').style.visibility = 'hidden';
     }
   
      function start(){
	get_chat_msg();";
	if($_SESSION[BASE.'chat']=="close"){
	  echo "chat_set_size('close');";
	}else{
	  echo "document.getElementById('chat_key').style.display = 'none';";
	}
echo "	
      }
    
       //=============SET NAKL FIELD====================================
      function catalog_view(parent){
      var div_mas =  document.getElementById('parent*'+parent);
      var div_mas1 = document.getElementById('parent_open*'+parent);
      var str = div_mas1.innerHTML;
      str = str.split(']');
          
	if(str[0]=='[+'){
	  div_mas1.innerHTML='[-]'+str[1];

	  var req=new JsHttpRequest();
      req.onreadystatechange=function(){
      if(req.readyState==4){
	 var responce=req.responseText;
	  div_mas.innerHTML=responce;
	  catalog_view_items(parent);
    }}
    req.open(null,'catalog_view.php',true);
    req.send({id:parent});	
	
	}else{
	  div_mas1.innerHTML='[+]'+str[1];
	  div_mas.innerHTML='';
	}

    }
      //=============CHAT====================================sent_chat_msg
 function sent_chat_msg(e){
      e=e||window.event;
	if(e.keyCode==13||e.keyCode==39){
		
	    var chat =  document.getElementById('chat');
	    var msg_txt =   document.getElementById('chat_txt').value;
	    document.getElementById('chat_txt').value = '';
	    var usr_to=document.getElementById('chat_user_id').value;
	    
	    var req=new JsHttpRequest();
	    req.onreadystatechange=function(){
 	      if(req.readyState==4){
		  var responce=req.responseText;
		  chat.innerHTML=responce;
		}}
	      req.open(null,'get_chat_msg.php',true);
	      req.send({msg:msg_txt,usr:usr_to});	
	}
      }
 function chat_set_size(e){
	
	if(e == 'large'){
	  document.getElementById('chat').style.height = '600px';
	  document.getElementById('chat_main').style.width = '450px';
	  document.getElementById('chat_tmp').style.display = 'block';
  	  document.getElementById('chat_key').style.display = 'none';
	}
	if(e == 'small'){
	//alert('gg');
	  document.getElementById('chat_main').style.display = 'block';
	  document.getElementById('chat').style.height = '50px';
	  document.getElementById('chat_main').style.width = '300px';
	  document.getElementById('chat_tmp').style.display = 'none';
	  document.getElementById('chat_key').style.display = 'none';
	  }
	if(e == 'close'){
	 // document.getElementById('chat').style.height = '0px';
	  //document.getElementById('chat_main').style.width = '0px';
	  document.getElementById('chat_main').style.display = 'none';
	  document.getElementById('chat_key').style.display = 'block';
	 // document.getElementById('chat_tmp').style.display = 'none';
	  //document.getElementById('chat_main').remove();
	}
	
	      var req=new JsHttpRequest();
	      req.onreadystatechange=function(){
	      if(req.readyState==4){
		  var responce=req.responseText;
		 // alert(responce);
	      }}	
	    req.open(null,'set_session.php',true);
	    req.send({set:e});
 
      }
 function chat_set_user(id,name){
  	document.getElementById('chat_user_id').value = id;
  	
  	if(id > 0)
  	{
	  document.getElementById('chat_user_name').value = '".$m_setup['chat personal']." '+name;
	}else{
	  document.getElementById('chat_user_name').value = ''+name;
	}
      }
 function get_chat_msg(){
      var chat =  document.getElementById('chat');
       // alert('hh');    
      var req=new JsHttpRequest();
      req.onreadystatechange=function(){
      
      if(req.readyState==4){
	 var responce=req.responseText;
	  chat.innerHTML=responce;
      }}
    req.open(null,'get_chat_msg.php',true);
    req.send(null);
    
    chat.scrollTop = 99999;
    setTimeout(get_chat_msg,10000);
    }";
	  if(isset($_SESSION[BASE.'usersetup'])){
	      if (strpos($_SESSION[BASE.'usersetup'],$_SESSION[BASE.'base'])>0){
		      echo "function set_chat_tmp(id){
			    var chat =  document.getElementById('chat_txt');
			      var req=new JsHttpRequest();
			      req.onreadystatechange=function(){
			      if(req.readyState==4){
				  var responce=req.responseText;
				  chat.value=responce;
			      }}
			      req.open(null,'get_chat_msg.php',true);
			      req.send({tmp:id});
			    }";
	      }
	  }   
echo "function chat_user_block(ip){
      var req=new JsHttpRequest();
      req.open(null,'get_chat_msg.php',true);
      req.send({block:ip});
}
    
function chat_msg_dell(id){
      var req=new JsHttpRequest();
      req.open(null,'get_chat_msg.php',true);
      req.send({dell:id});
}
   function info(msg){
	  document.getElementById('info2').innerHTML = msg;
	  if(msg==''){
	  	  document.getElementById('info2').style.display = 'none';
	  }else{
	  	  document.getElementById('info2').style.display = 'block';
	  	  //alert(msg);
	  }
}

//======================================================================      
    function addtovar(id){
    var id=id.split('*');
    var value = document.getElementById(id[1]);
      
      var req=new JsHttpRequest();
      req.onreadystatechange=function(){
      //alert(req.readyState);
      if(req.readyState==4){
 	 var responce=req.responseText;
	 if(responce=='nouser'){
	    window.location.replace('index.php?user=new');
	 }else{
	    alert(responce);
	    window.location.reload();
	 }
    }}
    req.open(null,'user_order.php',true);
    req.send({value:value.value,id:id[1],order:id[0]});
    }  


 
     </script>
      

";
//====================ADMIN SCRIPT ================================================
if (strpos($_SESSION[BASE.'usersetup'],$_SESSION[BASE.'base'])>0){
//echo "\n<script src='/admin/JsHttpRequest.js'></script>";
echo "\n<script type='text/javascript'>";
//================================SET COLOR=====================================
//================================SET PRICE===============kogda vibor konkretnoj ceni
echo "\nfunction update(table,name,value,id,tovar){
      //alert('ggg');
      
      var req=new JsHttpRequest();
      req.onreadystatechange=function(){
        if(req.readyState==4){
	var responce=req.responseText;
	document.getElementById('test').innerHTML=responce; //table,name,value,id,tovar
	
      }}
      req.open(null,'admin/save_table_field.php',true);
      req.send({table:table,name:name,value:value,w_id:id,w_value:tovar});
    //'tbl_parent_inet','parent_inet_sort',this.value,'parent_inet_id',this.id  
    }
   </script>
   
  ";

}
//=================================================================================
echo "
<div id=\"fb-root\"></div>
<script>
  window.fbAsyncInit = function() {
    FB.init({
      appId      : '1582359991987210',
      xfbml      : true,
      version    : 'v2.2'
    });
  };

  (function(d, s, id){
     var js, fjs = d.getElementsByTagName(s)[0];
     if (d.getElementById(id)) {return;}
     js = d.createElement(s); js.id = id;
     js.src = \"//connect.facebook.net/en_US/sdk.js\";
     fjs.parentNode.insertBefore(js, fjs);
   }(document, 'script', 'facebook-jssdk'));
</script>

";

  echo "</head>  
  <body onload=\"start();\" onmouseover=\"hidde_elem();\">";

$body = "";
$find="";
if(isset($_REQUEST['find']))$find=mysql_real_escape_string($_REQUEST['find']);

$parent=0;
if(isset($_REQUEST['parent']))
  $_REQUEST['parent'];

  if(isset($_REQUEST['parent'])&&!isset($_REQUEST['tovar'])){
      if($_REQUEST['parent']=='last' or $_REQUEST['parent']=='-1'){
	$body = user_last_item_list_view(120,$k_setup);
      }elseif($_REQUEST['parent']=='-2'){ //last operation list tovar
	$body = last_operation_list_tovar($m_setup);
      }elseif($_REQUEST['parent']=='-3'){ //no photo list tovar
	$body = no_photo_list_tovar($m_setup);
      }elseif($_REQUEST['parent']=='watch'){
	  if(isset($_REQUEST['dell']) and isset($_SESSION[BASE.'userid'])){
	      $dell = mysql_query("SET NAMES utf8");
	      $dell = mysql_query("DELETE FROM `tbl_opa` 
				  WHERE 
				  `opa_tovar`='".mysql_real_escape_string($_REQUEST['dell'])."' and 
				  `opa_klient`='".$_SESSION[BASE.'userid']."'");

	  }
	    $body = user_selected_item_list_view($k_setup,$m_setup);
      }else{
	
	$body .= "".user_catalog_path(mysql_real_escape_string($_REQUEST['parent'])). "<br><br>";
	$body .= user_subcatalog_view(mysql_real_escape_string($_REQUEST['parent']));
	$body .= user_item_list_view(mysql_real_escape_string($_REQUEST['parent']),$k_setup);
      }
  }elseif(isset($_REQUEST['find'])){
	$body = find_result(mysql_real_escape_string($_REQUEST['find']),$m_setup,$k_setup);
  }elseif(isset($_REQUEST['operation_id'])){
	    if(isset($_SESSION[BASE.'usersetup'])){
		if (strpos($_SESSION[BASE.'usersetup'],$_SESSION[BASE.'base'])>0){
		    $body = user_operation_list_view(mysql_real_escape_string($_REQUEST['operation_id']),$m_setup);
	    }}
  }elseif(isset($_REQUEST['user'])){
	if($_REQUEST['user']=="new" and !isset($_SESSION[BASE.'userid'])){
	    $body = user_registration($m_setup,$_REQUEST,$k_setup);
	}elseif($_REQUEST['user']=="edit"){
	    $body = user_edit($m_setup,$_REQUEST);
	}elseif($_REQUEST['user']=="rem_pass"){
	    $body = user_rem_pass($m_setup,$_REQUEST);
	}elseif($_REQUEST['user']=="send_order"){
	    $body = send_order($m_setup,$_REQUEST);
	}elseif($_REQUEST['user']=="order_list"){
	    $body = user_order_list($m_setup);
	}elseif($_REQUEST['user']=="price_excel"){
	    $body = user_price_excel($m_setup);
	}elseif($_REQUEST['user']=="utilites"){
	    $body = utilites($m_setup);
	}elseif($_REQUEST['user']=="view_order"){
	    $body = view_order($m_setup,$_REQUEST);
	}
  }elseif(isset($_REQUEST['submit'])){
	if($_REQUEST['submit']==$m_setup['menu user register']){
	    $body = user_registration($m_setup,$_REQUEST,$k_setup);
	}elseif($_REQUEST['submit']==$m_setup['menu user edit']){
	    $body = user_edit($m_setup,$_REQUEST);
	}
	
  }elseif(isset($_REQUEST["tovar"])) {
	$parent=0;
	if(isset($_REQUEST['parent'])) {
	      $perent = mysql_real_escape_string($_REQUEST['parent']);
	  }else{
	      $parentSQL = mysql_query("SET NAMES utf8");
	      $parentSQL = mysql_query("SELECT `tovar_inet_id_parent` FROM `tbl_tovar` WHERE `tovar_id`='".mysql_real_escape_string($_REQUEST["tovar"])."'");
	      if(mysql_num_rows($parentSQL)>0){
		$parent = mysql_result($parentSQL,0,0);
	      }
	  }
	$body = user_catalog_path($parent). "<br>";
	if(is_numeric($_REQUEST["tovar"])){
	    $body .= user_item_view((int)mysql_real_escape_string($_REQUEST["tovar"]));
	}
  }else{
	if(isset($_REQUEST['error'])){
	     $body .= error_msg(mysql_real_escape_string($_REQUEST['error']),$m_setup);
	}
      $body .= "<div style=\"Z-INDEX:0;\"> <table width=\"100%\" class=\"baner\" border=\"0px\">
	      <tr><td align=center>
	      <object width=\"900\" height=\"300\" >";
      $body .= banerMain("BanerLargeLeft",350,300);
      $body .= banerMain("BanerLargeCenter",600,300);
      $body .= "</object>
	      </td></tr></table>
	      </div>";
	if(isset($_REQUEST["key"])){
	    
	    $body .= info(100,$m_setup,mysql_real_escape_string($_REQUEST["key"]));
	    
	}
      $body .= user_last_item_list_view(8,$k_setup);
  }
$korzina="";  
if(isset($_SESSION[BASE.'userorder'])) {
    $korzina .= "<div id='order_item' class='order_items'> ";
    $korzina .= "".$m_setup['menu order']." #".$_SESSION[BASE.'userorder'];
    $korzina .= "<BR><b>".$_SESSION[BASE.'userordersumm']." ".$_SESSION[BASE.'usercurr']."</b>";
    $korzina .= "<br><table>
			<tr><td><a href='index.php?user=view_order' class='middle_link'>
				   <img src=\"resources/carts.png\"></a></td><td>
		    <b><a href='index.php?user=view_order' class='middle_link'>".$m_setup['menu order send']."</a></b></td></tr></table>";
    $korzina .= "<br>".order_item_view();
    //$korzina .= "<br><br><b><a href='index.php?user=view_order' class='big_link'>".$m_setup['menu order add']."</a></b>";
    $korzina .= "</div>";
}
$tmp_header = str_replace("&chat",chat(),$tmp_header);
$tmp_header = str_replace("&body",$body,$tmp_header);
$tmp_header = str_replace("&order",$korzina,$tmp_header);
$tmp_header = str_replace("&user_menu_catalog",user_menu_catalog($m_setup),$tmp_header);
//$tmp_header = str_replace("&user_menu_catalog",user_menu_catalog2()."<br>".user_menu_catalog(),$tmp_header);
$tmp_header = str_replace("&find",find_tovar($find,$m_setup,$k_setup),$tmp_header);
$tmp_header = str_replace("&user_menu_logo",user_menu_logo(),$tmp_header);
$tmp_header = str_replace("&user_menu_phone",user_menu_phone(),$tmp_header);
$social_key=
  "";
$tmp_header = str_replace("&social_key",$social_key,$tmp_header);
$tmp_header = str_replace("&user_menu_lang",user_menu_lang(),$tmp_header);
$tmp_header = str_replace("&user_menu_top",user_menu_top(),$tmp_header);
$tmp_header = str_replace("&news",info(1,$m_setup,"news"),$tmp_header);
$tmp_header = str_replace("&top_main_info",info(1,$m_setup,"top_main_info"),$tmp_header);

if(isset($_REQUEST['parent'])){
  $tmp = "".user_catalog_path_memo(mysql_real_escape_string($_REQUEST['parent']))."";
  }else{
  $tmp = "".user_catalog_path_memo(0)."";
  }
$tmp_header = str_replace("&sturm_memo",$tmp,$tmp_header);

$tmp_header = str_replace("&menu_main",$m_setup['menu main'],$tmp_header);
$tmp_header = str_replace("&menu_news",$m_setup['menu news'],$tmp_header);
$tmp_header = str_replace("&menu_forum",$m_setup['menu forum'],$tmp_header);
$tmp_header = str_replace("&menu_pay",$m_setup['menu pay'],$tmp_header);
$tmp_header = str_replace("&menu_deliv",$m_setup['menu deliv'],$tmp_header);
$tmp_header = str_replace("&menu_help",$m_setup['menu help'],$tmp_header);
$tmp_header = str_replace("&menu_adr",$m_setup['menu adr'],$tmp_header);
$tmp_header = str_replace("&menu_phone",$m_setup['menu phone nom'],$tmp_header);
$tmp_header = str_replace("&menu_work_time",$m_setup['menu work time'],$tmp_header);

$tmp_header = str_replace("&user_login",session_verify($_SERVER["PHP_SELF"]."?".$_SERVER['QUERY_STRING']),$tmp_header);
$tmp_header .= "<div id='info2' class='info'></div></body>
		";
echo $tmp_header;
echo "";
echo $_SESSION[BASE.'chat'];
echo "</html>";
?>
