<?php

print_r("test");

print_r(phpinfo());
?>
