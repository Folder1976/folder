<?php

include 'init.lib.php';
connect_to_mysql();

header ('Content-Type: text/html; charset=utf-8');
session_start();
if (!session_verify($_SERVER["PHP_SELF"],"+")){
  exit();
}
//connect_to_mysql();

$count = 0;
//$iKey_add = $_REQUEST["_add"];
//$iKey_save = $_REQUEST["_save"];
//$iKey_dell = $_REQUEST["_dell"];
$id_value = $_REQUEST["_id_value"];
$page_to_return = $_REQUEST["_page_to_return"];


//echo $iKey_add, $iKey_dell, $iKey_save, "- > <br>";



$ver = mysql_query("SET NAMES utf8");
//echo "<br>",$iKey_dell,"<br>";
if (isset($_REQUEST["_dell"]))
{
echo "dell";
    $ver = mysql_query("DELETE FROM `tbl_tovar` WHERE `tovar_id` ='".$id_value."'");
    echo "DELETE FROM `tbl_tovar` WHERE `tovar_id` ='".$id_value."' - ", $ver,"<br>";
    $ver = mysql_query("DELETE FROM `tbl_warehouse_unit` WHERE `warehouse_unit_tovar_id`='".$id_value."'");
    echo "DELETE FROM `tbl_warehouse_unit` WHERE `warehouse_unit_tovar_id`='".$id_value."' - ",$ver,"<br>";
    $ver = mysql_query("DELETE FROM `tbl_price_tovar` WHERE `price_tovar_id`='".$id_value."'");
    echo "DELETE FROM `tbl_price_tovar` WHERE `price_tovar_id`='".$id_value."' - ",$ver,"<br>";
    $ver = mysql_query("DELETE FROM `tbl_description` WHERE `descripton_tovar_id`='".$id_value."'");
    echo "DELETE FROM `tbl_description` WHERE `description_tovar_id`='".$id_value."' - ",$ver,"<br>";
    $result_string = "<br><br>Nom -> " . $id_value . " - DELETED OK";
}

if (isset($_REQUEST["_save"]))
{
//Update tovar ================================================================
//echo $_REQUEST['tovar_inet_id'];
$date = date("Y-m-d G:i:s");
    $sql_str = "UPDATE `tbl_tovar` SET ";
	if(strpos($_SESSION[BASE.'usersetup'],'tovar_code')>0) $sql_str .= "`tovar_code`='".$_REQUEST['tovar_code']."',";
	if(strpos($_SESSION[BASE.'usersetup'],'tovar_barcode')>0) $sql_str .= "`tovar_barcode`='".$_REQUEST['tovar_barcode']."',";
	if(strpos($_SESSION[BASE.'usersetup'],'tovar_parent')>0) $sql_str .= "`tovar_parent`='".$_REQUEST['tovar_parent']."',";
	if(strpos($_SESSION[BASE.'usersetup'],'tovar_artkl')>0) $sql_str .= "`tovar_artkl`	='".$_REQUEST['tovar_artkl']."',";
	if(strpos($_SESSION[BASE.'usersetup'],'tovar_size')>0) $sql_str .= "`tovar_size`	='".$_REQUEST['tovar_size']."',";
	if(strpos($_SESSION[BASE.'usersetup'],'tovar_name_1')>0) $sql_str .= "`tovar_name_1`='".$_REQUEST['tovar_name_1']."',";
	if(strpos($_SESSION[BASE.'usersetup'],'tovar_name_2')>0) $sql_str .= "`tovar_name_2`='".$_REQUEST['tovar_name_2']."',";
	if(strpos($_SESSION[BASE.'usersetup'],'tovar_name_3')>0) $sql_str .= "`tovar_name_3`='".$_REQUEST['tovar_name_3']."',";
	if(strpos($_SESSION[BASE.'usersetup'],'tovar_memo')>0) $sql_str .= "`tovar_memo`	='".$_REQUEST['tovar_memo']."',";
	if(strpos($_SESSION[BASE.'usersetup'],'tovar_dimension')>0) $sql_str .= "`tovar_dimension`='".$_REQUEST['tovar_dimension']."',";
	if(strpos($_SESSION[BASE.'usersetup'],'tovar_supplier')>0) $sql_str .= "`tovar_supplier`='".$_REQUEST['tovar_supplier']."',";
	if(strpos($_SESSION[BASE.'usersetup'],'tovar_min_order')>0) $sql_str .= "`tovar_min_order`='".$_REQUEST['tovar_min_order']."',";
	if(strpos($_SESSION[BASE.'usersetup'],'tovar_seazon')>0) $sql_str .= "`tovar_seazon`	='".$_REQUEST['tovar_seazon']."',";
	if(strpos($_SESSION[BASE.'usersetup'],'tovar_inet_id')>0) $sql_str .= "`tovar_inet_id`	='".$_REQUEST['tovar_inet_id']."',";
	if(strpos($_SESSION[BASE.'usersetup'],'tovar_last_edit')>0) $sql_str .= "`tovar_last_edit`='".$date."',";
	if(strpos($_SESSION[BASE.'usersetup'],'tovar_inet_id_parent')>0) $sql_str .= "`tovar_inet_id_parent`='".$_REQUEST['tovar_inet_id_parent']."',";
	
	$sql_str = substr($sql_str,0,-1)." WHERE `tovar_id`='".$id_value."'
		";
    $ver = mysql_query($sql_str);
    echo $sql_str." - ", $ver,"<br>";

//Update price ================================================================
     $sql_str = "UPDATE `tbl_price_tovar` SET ";
     $count=0;
     while($count++ < $_REQUEST['_price_count']){
	    if(strpos($_SESSION[BASE.'usersetup'],"price_tovar_".$count)>0){
		$sql_str .= "`price_tovar_".$count."`	 ='".$_REQUEST['price_tovar_'.$count]."',";
		$sql_str .= "`price_tovar_curr_".$count."`='".$_REQUEST['price_tovar_curr_'.$count]."',";
		$sql_str .= "`price_tovar_cof_".$count."`='".$_REQUEST['price_tovar_cof_'.$count]."',";
	    }    
      }
     $sql_str = substr($sql_str,0,-1)." WHERE `price_tovar_id`='".$id_value."'";
     $ver = mysql_query($sql_str);
     echo $sql_str." - ", $ver,"<br>";

//Update description ================================================================
   $sql_str = "UPDATE `tbl_description` SET ";
     $count=0;
     while($count++ < $_REQUEST['_description_count']){
	$sql_str .= "`description_".$count."`	 ='".$_REQUEST['description_'.$count]."',";
    }
     $sql_str = substr($sql_str,0,-1)." WHERE `description_tovar_id`='".$id_value."'";
     $ver = mysql_query($sql_str);
     echo $sql_str." - ", $ver,"<br>";

}
if (isset($_REQUEST["_add"]))
{
//Insert tovar ================================================================
echo $_REQUEST['tovar_inet_id'];
$date = date("Y-m-d G:i:s");
    $sql_str = "INSERT INTO `tbl_tovar` (
		`tovar_barcode`,
		`tovar_parent`,
		`tovar_artkl`,
		`tovar_size`,
		`tovar_name_1`,
		`tovar_name_2`,
		`tovar_name_3`,
		`tovar_memo`,
		`tovar_dimension`,
		`tovar_supplier`,
		`tovar_min_order`,
		`tovar_seazon`,
		`tovar_last_edit`,
		`tovar_inet_id_parent`,
		`tovar_inet_id`,
		`tovar_purchase_currency`,
		`tovar_sale_currency`
		)VALUES(
		'".$_REQUEST['tovar_barcode']."',
		'".$_REQUEST['tovar_parent']."',
		'".$_REQUEST['tovar_artkl']."',
		'".$_REQUEST['tovar_size']."',
		'".$_REQUEST['tovar_name_1']."',
		'".$_REQUEST['tovar_name_2']."',
		'".$_REQUEST['tovar_name_3']."',
		'".$_REQUEST['tovar_memo']."',
		'".$_REQUEST['tovar_dimension']."',
		'".$_REQUEST['tovar_supplier']."',
		'".$_REQUEST['tovar_min_order']."',
		'".$_REQUEST['tovar_seazon']."',
		'".$date."',
		'".$_REQUEST['tovar_inet_id_parent']."',
		'1',
		'2',
		'4'
		)";
    $ver = mysql_query($sql_str);
    $id_value=mysql_insert_id();
    echo $sql_str." - ", $ver," Inserted = ",$id_value,"<br>";
    
    $sql_str = "UPDATE `tbl_tovar` SET `tovar_inet_id`='".$id_value."' WHERE `tovar_id`='".$id_value."'";
    $ver = mysql_query($sql_str);
    echo $sql_str." - ", $ver," Inserted = ",$id_value,"<br>";
//Clear subtable if is present ==================================================================  
    $ver = mysql_query("DELETE FROM `tbl_warehouse_unit` WHERE `warehouse_unit_tovar_id`='".$id_value."'");
    echo "DELETE FROM `tbl_warehouse_unit` WHERE `warehouse_unit_tovar_id`='".$id_value."' - ",$ver,"<br>";
    $ver = mysql_query("DELETE FROM `tbl_price_tovar` WHERE `price_tovar_id`='".$id_value."'");
    echo "DELETE FROM `tbl_price_tovar` WHERE `price_tovar_id`='".$id_value."' - ",$ver,"<br>";
    $ver = mysql_query("DELETE FROM `tbl_description` WHERE `descripton_tovar_id`='".$id_value."'");
    echo "DELETE FROM `tbl_description` WHERE `description_tovar_id`='".$id_value."' - ",$ver,"<br>";
  
//Insert price ================================================================
     $sql_str = "INSERT INTO `tbl_price_tovar` (";
     $count=0;
     while($count++ < $_REQUEST['_price_count']){
	$sql_str .= "`price_tovar_".$count."`,`price_tovar_curr_".$count."`,`price_tovar_cof_".$count."`,";
      }
      $sql_str .= "`price_tovar_id`)VALUES(";
     
     $count=0;
     while($count++ < $_REQUEST['_price_count']){
	$sql_str .= "'".$_REQUEST['price_tovar_'.$count]."','".$_REQUEST['price_tovar_curr_'.$count]."','".$_REQUEST['price_tovar_cof_'.$count]."',";
      }
      $sql_str .= "'".$id_value."')";
     
     $ver = mysql_query($sql_str);
     echo $sql_str." - ", $ver,"<br>";
//Insert description ================================================================
     $sql_str = "INSERT INTO `tbl_description` (";
     $count=0;
     while($count++ < $_REQUEST['_description_count']){
	$sql_str .= "`description_".$count."`,";
      }
      $sql_str .= "`description_tovar_id`)VALUES(";
     
     $count=0;
     while($count++ < $_REQUEST['_description_count']){
	$sql_str .= "'".$_REQUEST['description_'.$count]."',";
      }
      $sql_str .= "'".$id_value."')";
     $ver = mysql_query($sql_str);
     echo $sql_str." - ", $ver,"<br>";

//Insert description ================================================================
     $sql_str = "INSERT INTO `tbl_warehouse_unit` (`warehouse_unit_tovar_id`) VALUES ('".$id_value."')";
     $ver = mysql_query($sql_str);
     echo $sql_str." - ", $ver,"<br>";
}
echo "<br>---",$id_value;
header ('Refresh: 1; url=edit_tovar.php?tovar_id='.$id_value);

?>
