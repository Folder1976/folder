<?php
ini_set('date.timezone', 'Europe/Kiev');
define('DB_PREFIX', 'e_', true);
define('HOST', '62.149.10.250', true);
define('DB', 'sturm_com_ua', true);
define('USER_DB', 'sturm_com_ua', true);
define('PASS_DB', 'v7PZqzrnGENwzp', true);
define('MAGIC_FILE', null);
//define('DEBUG_SQL', true, true);
//define('DEBUG_TIME', true, true);
?>