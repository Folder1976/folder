<?php
include 'init.lib.php';
connect_to_mysql();
session_start();
if (!session_verify($_SERVER["PHP_SELF"],"none")){
  exit();
}


//==================================SETUP===========================================
if ($_SESSION[BASE.'lang'] <1){
  $_SESSION[BASE.'lang']=1;
}
$setup = mysql_query("SET NAMES utf8");
$tQuery = "SELECT 
	  `setup_menu_name`, 
	  `setup_menu_".$_SESSION[BASE.'lang']."`
	  FROM `tbl_setup_menu`
";
//echo $tQuery;
$setup = mysql_query($tQuery);
$m_setup = array();
$count=0;
while ($count<mysql_num_rows($setup)){
 $m_setup[mysql_result($setup,$count,0)]=mysql_result($setup,$count,1);
 $count++;
}
//==================================SETUP=MENU==========================================


header ('Content-Type: text/html; charset=utf8');
echo "<header><link rel='stylesheet' type='text/css' href='sturm.css'>
<title>Setup</title>
</header>";

echo "<table  class='menu_top'>";
echo "<tr><td><a href='edit_klient.php' target='_blank'>",$m_setup['setup klient'],"</a></td></tr>";
echo "<tr><td><a href='edit_klienti_group.php' target='_blank'>",$m_setup['setup klient group'],"</a></td></tr>";
echo "<tr><td><a href='edit_delivery.php' target='_blank'>",$m_setup['setup delivery'],"</a></td></tr>";
echo "<tr><td><a href='edit_nakl-group.php' target='_blank'>",$m_setup['setup nakl'],"</a></td></tr>";
echo "<tr><td><a href='edit_inet_parent_table.php' target='_blank'>",$m_setup['setup nakl inet'],"</a></td></tr>";
echo "<tr><td><a href='edit_status.php' target='_blank'>",$m_setup['setup status'],"</a></td></tr>";
echo "<tr><td><a href='edit_warehouse.php' target='_blank'>",$m_setup['setup warehouse'],"</a></td></tr>";
echo "<tr><td><a href='edit_shop.php' target='_blank'>",$m_setup['setup shop'],"</a></td></tr>";
echo "<tr><td><a href='none.php' target='_blank'>",$m_setup['setup price'],"</a></td></tr>";
echo "<tr><td><a href='edit_curr.php' target='_blank'>",$m_setup['setup curr'],"</a></td></tr>";
echo "<tr><td></td></tr>";
echo "<tr><td>* * * WORK * * *</td></tr>";
if (strpos($_SESSION[BASE.'usersetup'],"analitics")>0){
echo "<tr><td><a href='get_analitics.php' target='_blank'>",$m_setup['menu klient analitics'],"</a></td></tr>";
}
echo "<tr><td><a href='get_findlog.php' target='_blank'>",$m_setup['menu findlog'],"</a></td></tr>";

echo "<tr><td>* * * SYSTEM * * *</td></tr>";
echo "<tr><td><a href='set_all_ostatki.php' target='_blank'>",$m_setup['menu set_all_ostatki'],"</a></td></tr>";
echo "<tr><td><a href='clear_op_det.php' target='_blank'>",$m_setup['menu clear_op_det'],"</a></td></tr>";
echo "<tr><td><a href='restore_nakl.php' target='_blank'>",$m_setup['menu restore_nakl'],"</a></td></tr>";
echo "<tr><td><a href='restore_nakl_field.php' target='_blank'>",$m_setup['menu restore_nakl_field'],"</a></td></tr>";
echo "<tr><td>* * * * * * * * * *</td></tr>";
echo "<tr><td><a href='edit_info.php' target='_blank'>",$m_setup['menu news']," - ",$m_setup['menu help'],"</a></td></tr>";
echo "<tr><td><a href='send_mail_all.php' target='_blank'>",$m_setup['menu send to all'],"</a></td></tr>";
echo "<tr><td></td></tr>";
echo "<tr><td></td></tr>";
if (strpos($_SESSION[BASE.'usersetup'],"habibulin")>0){
    echo "<tr><td><a href='edit_habibulin_parent.php?habibulin_parent_id=last' target='_blank'>",$m_setup['setup habibulin parent'],"</a></td></tr>";
    echo "<tr><td><a href='get_habibulin.php' target='_blank'>",$m_setup['setup habibulin'],"</a></td></tr>";
    echo "<tr><td></td></tr>";
    echo "<tr><td></td></tr>";
}
echo "<tr><td><a href='import_sql.php' target='_blank'>",$m_setup['setup import SQL'],"</a></td></tr>";
echo "<tr><td><a href='import_file.php' target='_blank'>",$m_setup['setup import file'],"</a></td></tr>";
//echo "<tr><td><a href='import_bane.php' target='_blank'>",$m_setup['setup import file'],"</a></td></tr>";
echo "<tr><td><a href='import_pic.php' target='_blank'>",$m_setup['setup import pic'],"</a></td></tr>";
echo "<tr><td></td></tr>";
echo "<tr><td></td></tr>";
echo "<tr><td></td></tr>";
if($_SESSION[BASE.'userlevel']>900000){
  echo "<tr><td><a href='admin_edit.php' target='_blank'>",$m_setup['setup admin'],"</a></td></tr>";
  echo "<tr><td><a href='translate_name.php?tovar_id=all' target='_blank'>",$m_setup['menu setup translate'],"</a></td></tr>";
}
echo "<tr><td></td></tr>";
//echo "<tr><td><a href='res.php' target='_blank'>",$m_setup['setup import pic'],"</a></td></tr>";

echo "</tr></table>";
//echo "<td><a href='edit_tovar_find.php?operation_id=0&_find=find-str' target='_blank'>New nakl</a></td>";
//echo "</td></tr></table>"; #Global Table


?>
