<?php
include 'init.lib.php';
include 'nakl.lib.php';

connect_to_mysql();
session_start();

require("JsHttpRequest.php");
$JsHttpRequest=new JsHttpRequest("utf8");//"windows-1251");


header ('Content-Type: text/html; charset=utf8');
$count =0;
if(isset($_REQUEST['count'])) $count = $_REQUEST['count'];

$ver = mysql_query("SET NAMES utf8");
$tQuery = "SELECT `tovar_id`,`tovar_artkl`
	    FROM `tbl_tovar`
	    ORDER BY `tovar_id` DESC
	    LIMIT $count, 1
	   ";
	  // echo $tQuery;
$ver = mysql_query($tQuery);

echo mysql_result($ver,0,"tovar_id")," - ",mysql_result($ver,0,"tovar_artkl");
echo "<header><title>RESET Warehouse</title></header>";
$tovar = mysql_result($ver,0,"tovar_id");

//reset_warehouse_on_tovar_from_to($tovar,1,14);
reset_warehouse_on_tovar_from_to($tovar,3,4);
reset_warehouse_on_tovar_from_to($tovar,4,5);
reset_warehouse_on_tovar_from_to($tovar,7,8);
reset_warehouse_on_tovar_from_to($tovar,9,10);
reset_warehouse_on_tovar_from_to($tovar,11,12);
reset_warehouse_on_tovar_from_to($tovar,2,13);


$count++;


if(mysql_num_rows($ver)>0){
header ('Refresh: 5; url=set_all_ostatki.php?count='.$count);
}else{
echo "END";
}




?>
