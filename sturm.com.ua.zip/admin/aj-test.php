<?php

require("JsHttpRequest.php");
$JsHttpRequest=new JsHttpRequest("windows-1251");


$http = "<b>ZALUPA</b>";
echo $http;



?>