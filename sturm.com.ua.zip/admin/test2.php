<?php

$test = parent.document.getelementsbytagname('frameset')[0];
echo  " - > ";// , $test;

?>
