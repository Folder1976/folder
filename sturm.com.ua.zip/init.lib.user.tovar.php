<?php
function user_item_view($id){
//connect_to_mysql();
$html = "";
$temp_header = "admin/template/tovar_view_header.html";

$parent_id=0;
if(isset($_REQUEST['parent'])) $parent_id=$_REQUEST['parent'];
   
 $html .= "</script>";
//=======================================================
$setup = mysql_query("SET NAMES utf8");
$tQuery = "SELECT 
	  `setup_name`, 
	  `setup_param`
	  FROM `tbl_setup`
";
$setup = mysql_query($tQuery);
$m_setup = array();
$count=0;
while ($count<mysql_num_rows($setup)){
 $m_setup[mysql_result($setup,$count,0)]=mysql_result($setup,$count,1);
 $count++;
}
//==================================SETUP=MENU==========================================
$setup = mysql_query("SET NAMES utf8");
$tQuery = "SELECT 
	  `setup_menu_name`, 
	  `setup_menu_".$_SESSION[BASE.'lang']."`
	  FROM `tbl_setup_menu`
	  ";

$setup = mysql_query($tQuery);
$k_setup = array();
$count=0;
while ($count<mysql_num_rows($setup)){
 $k_setup[mysql_result($setup,$count,0)]=mysql_result($setup,$count,1);
 $count++;
}

$fields = mysql_query("SET NAMES utf8");
$tQuery = "SELECT 	`tovar_inet_id_parent`,
			`tovar_artkl`,
			`tovar_name_".$_SESSION[BASE.'lang']."` AS tovar_name,
			`tovar_id`,
			`tovar_inet_id`,
			`price_tovar_".$m_setup['web default price']."` as price1,
			`price_tovar_".$_SESSION[BASE.'userprice']."` as price2,
			`price_tovar_curr_".$m_setup['web default price']."` as curr1,
			`price_tovar_curr_".$_SESSION[BASE.'userprice']."` as curr2,
			`description_".$_SESSION[BASE.'lang']."` AS tovar_description
			FROM 
			`tbl_tovar`,
			`tbl_price_tovar`,
			`tbl_description`
			WHERE 
			`tovar_id`=`price_tovar_id` and
			`tovar_id`=`description_tovar_id` and
			`tovar_id`='".$id."'
			";

$ver = mysql_query($tQuery);

if(mysql_num_rows($ver)<1){
}else{

$comm = mysql_query("SET NAMES utf8");
$tQuery = "SELECT 	
			`klienti_id`,
			`klienti_name_1`,
			`comments_memo`
			FROM 
			`tbl_comments`,
			`tbl_klienti`
			WHERE 
			`klienti_id`=`comments_klient` and
			`comments_tovar`='$id'
			ORDER BY `comments_id` DESC
			";
//echo $tQuery;
$comm = mysql_query($tQuery);
//echo $tQuery;
//==================================================================
$parent = mysql_query("SET NAMES utf8");
$tQuery = "SELECT 
	    `parent_inet_type`,
	    `parent_inet_info`
	  FROM 
	    `tbl_parent_inet`
	  WHERE
	     `parent_inet_id`='".mysql_result($ver,0,"tovar_inet_id_parent")."'
";
$parent = mysql_query($tQuery);
//=========================SELECT info=============================================
$info = mysql_query("SET NAMES utf8");
$tQuery = "SELECT 	
			`info_header_".$_SESSION[BASE.'lang']."` as info_header,
			`info_memo_".$_SESSION[BASE.'lang']."` as info_memo
			FROM 
			`tbl_info`
			WHERE 
			`info_id`='".mysql_result($parent,0,"parent_inet_info")."'
			";
//echo $tQuery;
$info = mysql_query($tQuery);
//=========================SELECT curr=============================================
$curr = mysql_query("SET NAMES utf8");
$SgetName = "SELECT *
		 FROM 
		`tbl_currency`
		";
$curr = mysql_query($SgetName);

if (!$curr){
  echo "Query error - tbl_currency - ",$SgetName;
  exit();
}

// get template================================
$tmp_header = file_get_contents($temp_header);



$size = mysql_result($parent,0,0);
// set size ======================================================
$link=$id;
if ($size==2){
    $id = mysql_result($ver,0,"tovar_inet_id_parent");
    $link = "GR".mysql_result($ver,0,"tovar_inet_id_parent");
    $id_inet = $id;
      $sql_size = mysql_query("SET NAMES utf8");
      $tQuery = "SELECT 
		    `tovar_id`,
		    `tovar_artkl`,
			`price_tovar_".$m_setup['web default price']."` as price1,
			`price_tovar_".$_SESSION[BASE.'userprice']."` as price2,
			`price_tovar_curr_".$m_setup['web default price']."` as curr1,
			`price_tovar_curr_".$_SESSION[BASE.'userprice']."` as curr2
		  FROM 
		     `tbl_tovar`,
		     `tbl_price_tovar`
		  WHERE
			`tovar_id`=`price_tovar_id` and
		      `tovar_inet_id_parent`='".$id_inet."'
";
    $sql_size = mysql_query($tQuery);
      $count=0;
      $str_size = "<table>";
      $str_size .= "<tr><td colspan=\"5\"><a href=\"index.php?key=size\" target=_blank>".$k_setup['tovar size lock size']."</a></td></tr>";
	  while($count < mysql_num_rows($sql_size)){
	  
	  //=================PRICE =========================================      
$price1=mysql_result($sql_size,$count,"price1");//Price for web
$pricename1="";
$priceex1 = 1;
$price2=mysql_result($sql_size,$count,"price2");//Price for user
$pricename2="";
$priceex2 = 1;

$count_tmp=0;
      while($count_tmp<mysql_num_rows($curr))
      {
	if(mysql_result($curr,$count_tmp,"currency_id")==mysql_result($sql_size,$count,"curr1"))
	{
	  $pricename1=mysql_result($curr,$count_tmp,"currency_name_shot");
	  $priceex1=mysql_result($curr,$count_tmp,"currency_ex");
	 }
	
	if(mysql_result($curr,$count_tmp,"currency_id")==mysql_result($sql_size,$count,"curr2"))
	{
	  $pricename2=mysql_result($curr,$count_tmp,"currency_name_shot");
	  $priceex2=mysql_result($curr,$count_tmp,"currency_ex");
	 }
	 
      $count_tmp++;
      }
      
$price2 = $price2*$priceex2/$priceex1; //Set web exange
$price2 = $price2/100*(100-$_SESSION[BASE.'userdiscount']);
$price2 = number_format($price2,2,'.','');
//================END=PRICE =========================================      
	    //$str_size .= "<tr><td colspan=\"5\">Tovar hame size</tr>";
	    
	    $str_size .= "<tr><td class='tovar_view_size'>".mysql_result($sql_size,$count,"tovar_artkl")."</td>";  //SIZE and ORDER ====
	    $str_size .= "<td class='tovar_on_ware'>";
	    $war_sum = tovar_on_ware(mysql_result($sql_size,$count,"tovar_id"));

	    $str_size .= tovar_on_ware_name($war_sum,$k_setup);
	    $str_size .= "</td>";  //SIZE and ORDER ====
	    
	      $str_size .= "<td><input type='text' class='order_in'";
		if ($_SESSION[BASE.'username']==null) $str_size .= " disabled='disabled' ";
	      $str_size .= "  id='".mysql_result($sql_size,$count,"tovar_id")."' value='1'></td>";  //SIZE and ORDER ====

	      if($price1==$price2){
		  $str_size .= "<td class='tovar_view_size'> &nbsp".$price1." ".$pricename1."&nbsp</td>";  //SIZE and ORDER ====
	      }else{
		  $str_size .= "<td class='tovar_view_size'> &nbsp".$price2." ".$pricename1." (".$price1." ".$pricename1.")&nbsp</td>";//User price
	      }
 
	   
	   $str_size .= "<td>";
	      if($war_sum > 0){
		 $str_size .= "<button class='order'";
		  //if ($_SESSION[BASE.'username']==null) $str_size .= " disabled='disabled' ";
		 $str_size .= " id='add*".mysql_result($sql_size,$count,"tovar_id")."' OnClick='addtovar(this.id);'><img src='resources/cart.png'> ".$k_setup['menu order add']."</button> ";  //SIZE and ORDER ====
	      }else{
		 $str_size .= "<input type='button' class='order'";
		 // if ($_SESSION[BASE.'username']==null) $str_size .= " disabled='disabled' ";
		 $str_size .= "value='".$k_setup['tovar opa add']."' id='opa*".mysql_result($sql_size,$count,"tovar_id")."' OnClick='addtovar(this.id);'>";  //SIZE and ORDER ====
	      }
	  	if (strpos($_SESSION[BASE.'usersetup'],$_SESSION[BASE.'base'])>0){
		  $str_size .= "<a href='admin/edit_tovar.php?tovar_id=".mysql_result($sql_size,$count,"tovar_id")."' class='admin'>".$k_setup['menu edit']."</a>";
		  }
	  $str_size .= "</td></tr>";
	
	    $count++;
	  }
      $str_size.="</table>";
	  
    $tmp_header = str_replace("&tovar_size",$str_size,$tmp_header);
}else{
	  //=================PRICE =========================================      
$price1=mysql_result($ver,0,"price1");//Price for web
$pricename1="";
$priceex1 = 1;
$price2=mysql_result($ver,0,"price2");//Price for user
$pricename2="";
$priceex2 = 1;

$count_tmp=0;
      while($count_tmp<mysql_num_rows($curr))
      {
	if(mysql_result($curr,$count_tmp,"currency_id")==mysql_result($ver,0,"curr1"))
	{
	  $pricename1=mysql_result($curr,$count_tmp,"currency_name_shot");
	  $priceex1=mysql_result($curr,$count_tmp,"currency_ex");
	 }
	
	if(mysql_result($curr,$count_tmp,"currency_id")==mysql_result($ver,0,"curr2"))
	{
	  $pricename2=mysql_result($curr,$count_tmp,"currency_name_shot");
	  $priceex2=mysql_result($curr,$count_tmp,"currency_ex");
	 }
	 
      $count_tmp++;
      }
      
$price2 = $price2*$priceex2/$priceex1; //Set web exange
$price2 = $price2/100*(100-$_SESSION[BASE.'userdiscount']);
$price2 = number_format($price2,2,'.','');
//================END=PRICE =========================================      

    $id_inet = mysql_result($ver,0,"tovar_inet_id");
	      //==================================
	      $war_sum = tovar_on_ware(mysql_result($ver,0,"tovar_id"));
	      $str_size = mysql_result($ver,0,"tovar_artkl");
	      //echo "----> ",$war_sum;
	      $str_size .= " &nbsp&nbsp(";
		/* if ($war_sum <1) $str_size .= $k_setup['tovar none'];
		  elseif ($war_sum >5) $str_size .= $k_setup['tovar more'];
		    else $str_size .= $k_setup['tovar many'];*/
		      $str_size .= tovar_on_ware_name($war_sum,$k_setup);
	      $str_size .= ") ";
	      
	      $str_size .= "<input type='text' class='order_in'";
		if ($_SESSION[BASE.'username']==null) $str_size .= " disabled='disabled' ";
	      $str_size .= "  id='".mysql_result($ver,0,"tovar_id")."' value='1'>";  //SIZE and ORDER ====
	    
	      if($price1==$price2){
		  $str_size .= "&nbsp<font class='tovar_view_size'>".$price1." ".$pricename1."</font>&nbsp";  //SIZE and ORDER ====
	      }else{
		  $str_size .= "&nbsp<font class='tovar_view_size'>".$price2." ".$pricename1."</font> (".$price1." ".$pricename1.")&nbsp";//User price
	      }
	    $str_size .= "";
	      if($war_sum > 0){
		 $str_size .= "<button class='order'";
		 // if ($_SESSION[BASE.'username']==null) $str_size .= " disabled='disabled' ";
		 $str_size .= " id='add*".mysql_result($ver,0,"tovar_id")."' OnClick='addtovar(this.id);'><img src='resources/cart.png'> ".$k_setup['menu order add']."</button>";  //SIZE and ORDER ====
	      }else{
		 $str_size .= "<input type='button' class='order'";
		 // if ($_SESSION[BASE.'username']==null) $str_size .= " disabled='disabled' ";
		 $str_size .= "value='".$k_setup['tovar opa add']."' id='opa*".mysql_result($ver,0,"tovar_id")."' OnClick='addtovar(this.id);'>";  //SIZE and ORDER ====
	      }
	      	  	if (strpos($_SESSION[BASE.'usersetup'],$_SESSION[BASE.'base'])>0){
		  $str_size .= "<a href='admin/edit_tovar.php?tovar_id=".mysql_result($ver,0,"tovar_id")."' class='admin'>".$k_setup['menu edit']."</a>";
		  }
	      //=============================
    $tmp_header = str_replace("&tovar_size",$str_size."",$tmp_header); //NO SIZE and ORDER ====
}
//=========================================
$comm_txt="";
$count=0;
$comm_txt.="
    <table class='menu_top'>
    <tr><td><b>COMMENTS:</b></td></tr>
    <tr><td>
    <form method='get' action='index.php'>
    <textarea cols='70' rows='2' id='comment_txt' name='comment_txt' onClick='clear_field();'>".$k_setup['menu add comment']."</textarea><br>
    <input type='submit' name='action' value='".$k_setup['menu add']."'";
    if(!isset($_SESSION[BASE.'userid'])) $comm_txt.= " disabled='disabled' ";
    $comm_txt.= ">
    <input type='hidden' name='parent' value='$parent_id'>
    <input type='hidden' name='tovar' value='$id'>
    ";
 	if (strpos($_SESSION[BASE.'usersetup'],$_SESSION[BASE.'base'])>0){
	  $comm_txt .= "<a href='admin/edit_comment.php?tovar_id=".$id."' class='admin'>".$k_setup['menu edit']."</a>";
	 }

    $comm_txt .= "</form></td></tr>";
  
    while($count<mysql_num_rows($comm))
    {
      $user = explode(" ",mysql_result($comm,$count,"klienti_name_1"));
	if(isset($user[1]))$user[0]=$user[1];
      $comm_txt .= "<tr><td>
		    <b>".$user[0]."</b>";
	  if (strpos($_SESSION[BASE.'usersetup'],$_SESSION[BASE.'base'])>0){
	    $comm_txt .= " <a href='admin/edit_comment.php?klient_id=".mysql_result($comm,$count,"klienti_id")."' class='admin'>".$k_setup['menu edit']."</a>";
	  }
      
 
      $comm_txt .= "<br>"
		    .mysql_result($comm,$count,"comments_memo")."
		    <br><br></td></tr>
		    ";
		    
    $count++;
    }
  
  $comm_txt.="</table>";
//==================================================================
echo "<header><link rel='stylesheet' type='text/css' href='sturm.css' media='all'>
	      <link rel='stylesheet' type='text/css' href='demo.css' media='all'></header>
      ";

      $tovar_name = explode($m_setup['tovar name sep'], mysql_result($ver,0,"tovar_name"));
      $artkl=explode($m_setup['tovar artikl-size sep'],mysql_result($ver,0,"tovar_artkl"));
echo "<title>",$tovar_name[0],"</title>";

$tmp_header = str_replace("&comments",$comm_txt,$tmp_header);
$tmp_header = str_replace("&tovar_name",$tovar_name[0],$tmp_header);
$tmp_header = str_replace("&tovar_artkl",$artkl[0],$tmp_header);
$tmp_header = str_replace("&info_header",mysql_result($info,0,"info_header"),$tmp_header);
$tmp_header = str_replace("&info_memo",mysql_result($info,0,"info_memo"),$tmp_header);

  $price_tovar="";
    if($price1==$price2){
	$price_tovar .= "<font class='tovar_view_size'>".$price1." ".$pricename1."</font>";  //SIZE and ORDER ====
    }else{
	$price_tovar .= "<font class='tovar_view_size'>".$price2." ".$pricename1." (".$price1." ".$pricename1.")</font>";//User price
    }

$tmp_header = str_replace("&price_tovar",$price_tovar,$tmp_header);
      $memo = mysql_result($ver,0,"tovar_description");
      $memo = str_replace("\r\n","<br>",$memo);
      //$memo = str_replace("\r","<br>",$memo);

$tmp_header = str_replace("&tovar_description",$memo,$tmp_header);


$photo = "";

$directory = "resources/products/".$link."/"; //название папки с изображениями
 
	    $allowed_types=array('jpg','jpeg','gif','png'); //типы изображений
	    $file_parts=array();
	    $ext='';
	    $title='';
	    $i=0;
	 if(@opendir($directory)!=false) 
	 {
	 
	      $dir_handle = @opendir($directory) or exit();//die("There is an error with your image directory!");
	 
	      while ($file = readdir($dir_handle)) //поиск
	      {
	        if($file=='.' || $file == '..' || strpos($file,'large') == 0) continue; //пропустить ссылки на другие папки
	        $file_parts = explode('.',$file); //разделение имени файла и размещение его в массиве
	        $ext = strtolower(array_pop($file_parts)); //расширение
	     
		$nomargin="";
		if(in_array($ext,$allowed_types))
	        {
	            if(($i+1)%4 == 0) $nomargin='nomargin'; 
	            $photo .= "<span style='color: rgb(51, 51, 51); font-family: \"Courier New\", Courier, monospace; font-size: 13px; line-height: 14px; text-align: left; '>";//последнему изображению в ряде присваевается CSS класс "nomargin"</span>
			
			  if($i==0) {$nomargin = "";}
			  else {$nomargin = "";}
			  $photo .= "<div class='pic".$nomargin."' style='background:url(".$directory."/".str_replace("large","medium",$file).") no-repeat 50% 50%;background-size:100%;'>
	                  <a href='".$directory."/".$file."' title='".$tovar_name[0]."' target='_blank'>".$tovar_name[0]."</a>
	                  </div>";
	            $i++;
	        }
	    }
	 
	    closedir($dir_handle); //закрыть папку
	    
	    $photo_all = "<div id='container'>";
	    
	    $photo_all .=  "<div id='gallery'>
			    $photo
			      <div class='clear'></div>
			    </div>";
	    $photo_all .="</div>";
	    $photo_all .= "
		      <link rel='stylesheet' type='text/css' href='lightbox/css/jquery.lightbox-0.5.css' >
		      <script type='text/javascript' src='http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js'></script>
		      <script type='text/javascript' src='lightbox/js/jquery.lightbox-0.5.pack.js'></script>
		      <script type='text/javascript' src='script.js'></script>
			";

	    $tmp_header = str_replace("&photo",$photo_all,$tmp_header);
	}else{
	    $tmp_header = str_replace("&photo","",$tmp_header);
	}
return $tmp_header;
}//проверка или вообще хоть чтото нашло
}
function tovar_on_ware_name($count,$k_setup){
$str = "";
    if ($count <0) $str .= $k_setup['tovar wait'];
     elseif ($count ==0) $str .= $k_setup['tovar none'];
     elseif ($count >5) $str .= $k_setup['tovar more'];
      else $str .= $k_setup['tovar many'];
      
return $str;

}
function tovar_on_ware($id){
      $ver = mysql_query("SET NAMES utf8");
      $tQuery = "SELECT 
		    `tovar_parent_nom`
		  FROM 
		     `tbl_tovar`,
		     `tbl_parent`
		  WHERE
			`tovar_parent`=`tovar_parent_id` and
			`tovar_id`='".$id."'
";
    $ver = mysql_query($tQuery);
    //echo $id,"<br>";
$war_key=mysql_result($ver,0,0)
;

$tmp="";
$zakaz_ware_id = 9;
$sum = 0;
$zakaz = 0;
$count=0;

  while(isset($war_key[$count])){
   if($war_key[$count]=="1" and ($count+1) <> $zakaz_ware_id) $tmp .= " `warehouse_unit_".($count+1)."` +"; //ne sczitaem 9 sklad ZAKAZ
     $count++;
  }
     $ver = mysql_query("SET NAMES utf8");
      $tQuery = "SELECT 
		    (".substr($tmp,0,-1).") as war_sum
		  FROM 
		     `tbl_warehouse_unit`
		  WHERE
		      `warehouse_unit_tovar_id`='".$id."'
";
if($tmp=="")
{
  $sum = 0;
}else{
  $ver = mysql_query($tQuery);
  $sum = mysql_result($ver,0,0);
  if($sum < 0) $sum = 0;
}
      $ver = mysql_query("SET NAMES utf8");
      $tQuery = "SELECT 
		    `warehouse_unit_".$zakaz_ware_id."`
		  FROM 
		     `tbl_warehouse_unit`
		  WHERE
		      `warehouse_unit_tovar_id`='".$id."'";
      $ver = mysql_query($tQuery);
      $zakaz = mysql_result($ver,0,0);
 // echo $zakaz," - ",$sum;
  if($sum == 0){
      if($zakaz > 0){
	  return -1;
      }else{
	  return 0;
      }
  }else{
      return $sum;
  }
      
}
function verify_order_and_send_email($order) {
  $nakl = mysql_query("SET NAMES utf8");
    $tQuery = "SELECT 
	  `operation_detail_tovar`
	  FROM
	  `tbl_operation_detail`
	  WHERE
	  `operation_detaol_dell`='0' and
	  `operation_detail_operation`='".$order."'
	  ";
  $nakl = mysql_query($tQuery);
  
$count=0;
while($count<mysql_num_rows($nakl)){
  
  echo tovar_on_ware(mysql_result($nakl,$count,0));

$count++;
}
  
  
}
?>
