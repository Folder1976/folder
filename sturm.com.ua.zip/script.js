$(document).ready(function(){
     
    $('.pic a').lightBox({
         
        imageLoading: 'lightbox/images/loading.gif',
        imageBtnClose: 'lightbox/images/close.gif',
        imageBtnPrev: 'lightbox/images/prev.gif',
        imageBtnNext: 'lightbox/images/next.gif'
 
    });
     
});