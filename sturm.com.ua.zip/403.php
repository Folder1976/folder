<?php

header ('Refresh: 0; url=https://sturm.com.ua/index.php?error=403');
?>
